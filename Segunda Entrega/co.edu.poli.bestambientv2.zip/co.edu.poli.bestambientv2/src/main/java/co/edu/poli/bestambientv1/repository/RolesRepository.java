package co.edu.poli.bestambientv1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.poli.bestambientv1.modelo.Roles;


public interface RolesRepository extends JpaRepository<Roles, String>{

}
