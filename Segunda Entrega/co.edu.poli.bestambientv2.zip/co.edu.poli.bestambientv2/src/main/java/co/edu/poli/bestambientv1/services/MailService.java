package co.edu.poli.bestambientv1.services;

import co.edu.poli.bestambientv1.modelo.Mail;

public interface MailService {

	public void sendEmail (Mail mail);
	
}